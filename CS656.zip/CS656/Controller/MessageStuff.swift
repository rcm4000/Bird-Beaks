//
//  MessageStuff.swift
//  ChatApp
//
//  Created by avtar singh on 11/29/18.
//  Copyright © 2018 CS656. All rights reserved.
//

import UIKit
import Firebase

class MessageStuff: NSObject {
    
    var SenderID: String?
    var text: String?
    var TimeSent: NSNumber?
    var RecieveID: String?
    
    init(dictionary: [String: Any]) {
        self.SenderID = dictionary["SenderID"] as? String
        self.text = dictionary["text"] as? String
        self.RecieveID = dictionary["RecieveID"] as? String
        self.TimeSent = dictionary["TimeSent"] as? NSNumber
    }
    
    func chatPartnerId() -> String? {
        
        if SenderID == Auth.auth().currentUser?.uid {
            return RecieveID
        } else {
            return SenderID
        }
    }

}
