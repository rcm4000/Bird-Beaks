//
//  ViewController.swift
//  ChatApp
//
//  Created by avtar singh on 11/13/18.
//  Copyright © 2018 CS656. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class ViewController: UITableViewController {
    
    let cellID = "cellId"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(Logout))
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "New Message", style: .plain, target: self, action: #selector(NewMessage))
        
        CheckLogin()
        
        tableView.register(UserCell.self, forCellReuseIdentifier: cellID)
        
        
    }
    
    var messages = [MessageStuff]()
    var messagesDictionary = [String: MessageStuff]()
    
    func WatchinguserMessage() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let ref = Database.database().reference().child("user-messages").child(uid)
        ref.observe(.childAdded, with: { (snapshot) in
            
            let messageId = snapshot.key
            let messageRef = Database.database().reference().child("messages").child(messageId)
            messageRef.observeSingleEvent(of: .value, with: { (snapshot) in
                
                if let dictionary = snapshot.value as? [String: AnyObject] {
                    let message = MessageStuff(dictionary: dictionary)
                    
                    
                    if let chatPartnerID = message.chatPartnerId() {
                        self.messagesDictionary[chatPartnerID] = message
                        
                        self.messages = Array(self.messagesDictionary.values)
                        self.messages.sort(by: { (message1, message2) -> Bool in
                            if let timestamp1 = message1.TimeSent, let timestamp2 = message2.TimeSent {
                                return timestamp1.intValue > timestamp2.intValue
                            }
                            return false
                        })
                        
                    }
                    self.timer?.invalidate()
                    self.timer = Timer.scheduledTimer(timeInterval: 0.10, target: self, selector: #selector(self.Reloader), userInfo: nil, repeats: false)
                    
                    
                }
                
                }, withCancel: nil)
            
            
         }, withCancel: nil)
    }
    
    var timer: Timer?
    
    @objc func Reloader() {
        DispatchQueue.main.async(execute: {
            self.tableView.reloadData()
        })
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! UserCell
        
        let message = messages[indexPath.row]
        cell.message = message
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let message = messages[indexPath.row]
        
        guard let chatPartnerId = message.chatPartnerId() else {
            return
        }
        
        let ref = Database.database().reference().child("users").child(chatPartnerId)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            
            print(snapshot)
            guard let dictionary = snapshot.value as? [String: AnyObject]
                else {
                    return
            }
            
            let user = User(dictionary: dictionary)
            user.id = chatPartnerId
            self.ChatController(user)
        
            
        }, withCancel: nil)

    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72
    }
    
    @objc func NewMessage() {
        let MessageControl = MessagePartController()
        MessageControl.MessagePush = self
        let navControl = UINavigationController(rootViewController: MessageControl)
        present(navControl, animated: true, completion: nil)
    }
    
    func CheckLogin() {
        if Auth.auth().currentUser?.uid == nil {
            perform(#selector(Logout), with: nil, afterDelay: 0)
        } else {
            GrabName()
        }
    }
    
    func GrabName() {
        
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        Database.database().reference().child("users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let user = User(dictionary: dictionary)
                self.NavBarSet(user)
            }
        }, withCancel: nil)
    }
    
    func NavBarSet(_ user: User) {
        messages.removeAll()
        messagesDictionary.removeAll()
        tableView.reloadData()
        
        WatchinguserMessage()
        
        let button = UIButton(type: .system)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        button.titleLabel?.textColor = UIColor(red: 10/255, green: 220/255, blue: 220/255, alpha: 1)
        button.setTitle(user.name, for: .normal)
        button.addTarget(self, action: #selector(ChatController), for: .touchUpInside)
        
        self.navigationItem.titleView = button
    }
    
    @objc func ChatController(_ user: User) {
        let Chatting = ChatControl(collectionViewLayout: UICollectionViewFlowLayout())
        Chatting.user = user
        navigationController?.pushViewController(Chatting, animated: true)
    }
    
    @objc func Logout() {
        
        do {
            try Auth.auth().signOut()
        } catch let logoutError {
            print(logoutError)
        }
        let LogOn = LoginPart()
        LogOn.viewControl = self
        present(LogOn, animated: true, completion: nil)
    }
    
}

