//
//  LoginViewController.swift
//  ChatApp
//
//  Created by Rayon on 11/27/18.
//  Copyright © 2018 CS656. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var anonymousButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    

    @IBAction func loginAnonymouslyDidTapped(_ sender: Any) {
        print ("login anonymously did tapped")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let naviVC =  storyboard.instantiateViewController(withIdentifier: "NavigationVC") as! UINavigationController
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        appDelegate.window?.rootViewController = naviVC;
    }
   
     @IBAction func googleLoginDidTapped(_ sender: Any) {
        print ("login anonymously did tapped")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let naviVC =  storyboard.instantiateViewController(withIdentifier: "NavigationVC") as! UINavigationController
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        appDelegate.window?.rootViewController = naviVC;
     }
     /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
