//
//  Login.swift
//  ChatApp
//
//  Created by avtar singh on 11/13/18.
//  Copyright © 2018 CS656. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class RegisterPart: UIViewController {
    
    let EntryField: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        return view
    }()
    let RegisterButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = UIColor.white
        button.setTitle("Register", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.layer.cornerRadius = 5
        
        button.addTarget(self, action: #selector(DoRegister), for: .touchUpInside)
        
        return button
    }()
    
    @objc func DoRegister() {
        guard let email = EmailField.text, let password = PasswordField.text, let name = NameField.text else {print("Form is not valid"); return}
        
        Auth.auth().createUser(withEmail: email, password: password, completion: { (res, error) in
            if error != nil {
                print(error)
                return
            }
            let ref = Database.database().reference(fromURL:"https://chatapp-66a91.firebaseio.com/")
            let values = ["name": name, "email": email]
            let usersReference = ref.child("users").child(Auth.auth().currentUser!.uid)
            usersReference.updateChildValues(values, withCompletionBlock: { (err, ref) in
                
                    if err != nil {
                     print(err!)
                  return
                 }
            })
            
            self.dismiss(animated: true, completion: nil)
        })
        
    }
    
    @IBAction func AlertSuccess(sender: AnyObject)
    {
        
        let myAlert = UIAlertController(title: "Alert", message: "You have successfully Registered. Please log in now", preferredStyle: .alert)
        let OkButton = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(OkButton)
        self.present(myAlert, animated: true, completion: nil)
        
    }
    
    let NameField: UITextField = {
        let name = UITextField()
        name.placeholder = "Name"
        name.translatesAutoresizingMaskIntoConstraints = false
        return name
    } ()
    
    let ExtraLine1: UIView = {
        let extra = UIView()
        extra.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        extra.translatesAutoresizingMaskIntoConstraints = false
        return extra
    } ()
    
    let PasswordField: UITextField = {
        let pass = UITextField()
        pass.placeholder = "Password"
        pass.translatesAutoresizingMaskIntoConstraints = false
        pass.isSecureTextEntry = true
        return pass
    } ()
    
    let ExtraLine2: UIView = {
        let extra = UIView()
        extra.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        extra.translatesAutoresizingMaskIntoConstraints = false
        return extra
    } ()
    
    let EmailField: UITextField = {
        let email = UITextField()
        email.placeholder = "Email"
        email.translatesAutoresizingMaskIntoConstraints = false
        return email
    } ()
    
    let ImageLoad: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "NJIT_Highlanders_wordmark.svg")
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    } ()
    
    let CancelButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Cancel", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.addTarget(self, action: #selector(openLoginPart), for: .touchUpInside)
        return button
    }()
    
    @objc func openLoginPart(){
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 200/255, green: 59/255, blue: 48/255, alpha: 1)
        
        view.addSubview(EntryField)
        view.addSubview(RegisterButton)
        view.addSubview(ImageLoad)
        view.addSubview(CancelButton)
        setupEntryField()
        setupRegisterButton()
        setupImage()
        setupCancelButton()
    }
    
    func setupCancelButton() {
        CancelButton.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        CancelButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 50).isActive = true
        CancelButton.widthAnchor.constraint(equalTo: EntryField.widthAnchor, constant: -300).isActive = true
        
    }
    
    func setupEntryField() {
        EntryField.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        EntryField.bottomAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        EntryField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -24).isActive = true
        EntryField.heightAnchor.constraint(equalTo: view.heightAnchor, constant: -700).isActive = true
        EntryField.addSubview(NameField)
        EntryField.addSubview(ExtraLine1)
        EntryField.addSubview(PasswordField)
        EntryField.addSubview(ExtraLine2)
        EntryField.addSubview(EmailField)
        NameField.leftAnchor.constraint(equalTo: EntryField.leftAnchor, constant: 12).isActive = true
        NameField.topAnchor.constraint(equalTo: EntryField.topAnchor).isActive = true
        NameField.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        NameField.heightAnchor.constraint(equalTo: EntryField.heightAnchor, multiplier: 1/3).isActive = true
        ExtraLine1.leftAnchor.constraint(equalTo: EntryField.leftAnchor).isActive = true
        ExtraLine1.topAnchor.constraint(equalTo: NameField.bottomAnchor).isActive = true
        ExtraLine1.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        ExtraLine1.heightAnchor.constraint(equalToConstant: 1).isActive = true
        PasswordField.leftAnchor.constraint(equalTo: EntryField.leftAnchor, constant: 12).isActive = true
        PasswordField.topAnchor.constraint(equalTo: NameField.bottomAnchor).isActive = true
        PasswordField.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        PasswordField.heightAnchor.constraint(equalTo: EntryField.heightAnchor, multiplier: 1/3).isActive = true
        ExtraLine2.leftAnchor.constraint(equalTo: EntryField.leftAnchor).isActive = true
        ExtraLine2.topAnchor.constraint(equalTo: PasswordField.bottomAnchor).isActive = true
        ExtraLine2.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        ExtraLine2.heightAnchor.constraint(equalToConstant: 1).isActive = true
        EmailField.leftAnchor.constraint(equalTo: EntryField.leftAnchor, constant: 12).isActive = true
        EmailField.topAnchor.constraint(equalTo: PasswordField.bottomAnchor).isActive = true
        EmailField.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        EmailField.heightAnchor.constraint(equalTo: EntryField.heightAnchor, multiplier: 1/3).isActive = true
        
    }
    
    func setupRegisterButton() {
        RegisterButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        RegisterButton.topAnchor.constraint(equalTo: EntryField.bottomAnchor, constant: 12).isActive = true
        RegisterButton.widthAnchor.constraint(equalTo: EntryField.widthAnchor).isActive = true
        RegisterButton.heightAnchor.constraint(equalTo: EntryField.heightAnchor, constant: -150).isActive = true
        
    }
    
    func setupImage(){
        ImageLoad.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        ImageLoad.bottomAnchor.constraint(equalTo: EntryField.topAnchor, constant: -12).isActive = true
        ImageLoad.widthAnchor.constraint(equalToConstant: 250).isActive = true
        ImageLoad.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }
    func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .lightContent
    }
    
    
}
