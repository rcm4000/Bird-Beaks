//
//  ChatControl.swift
//  ChatApp
//
//  Created by avtar singh on 11/29/18.
//  Copyright © 2018 CS656. All rights reserved.
//

import UIKit
import Firebase

class ChatControl: UICollectionViewController, UITextFieldDelegate, UICollectionViewDelegateFlowLayout {
    
    var user: User? {
        didSet {
            navigationItem.title = user?.name
            
            watchMessage()
        }
    }
    
    
    override var inputAccessoryView: UIView? {
        get {
            let containerView = UIView()
            containerView.frame = CGRect(x: 0, y:0, width: view.frame.width, height: 0)
            //containerView.backgroundColor = UIColor.yellow
            
            let textField = UITextField()
            textField.placeholder = "Enter"
            containerView.addSubview(textField)
            containerView.frame = CGRect(x: 0, y:0, width: view.frame.width, height: 0)
            return containerView
        }
    }
    override var canBecomeFirstResponder : Bool {
        return true
    }
    
    var messages = [MessageStuff]()
    
    func watchMessage() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        let userMessages = Database.database().reference().child("user-messages").child(uid)
        userMessages.observe(.childAdded, with: { (snapshot) in
            
            let messageID = snapshot.key
            let messagesRef = Database.database().reference().child("messages").child(messageID)
            messagesRef.observeSingleEvent(of: .value, with: { (snapshot) in
                
                guard let dictionary = snapshot.value as? [String: AnyObject] else {
                    return
                }
                
                let message = MessageStuff(dictionary: dictionary)
                
                
                if message.chatPartnerId() == self.user?.id {
               self.messages.append(message)
                DispatchQueue.main.async(execute: {
                    self.collectionView?.reloadData()
                })
                    
                }
                }, withCancel: nil)
            
            }, withCancel: nil)
    }
    lazy var inputTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter message..."
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.delegate = self
        return textField
    }()
    
    let cellID = "cellId"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView?.contentInset = UIEdgeInsets(top: 8, left: 0, bottom: 58, right: 0)
        collectionView?.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: 50, right: 0)
        collectionView?.alwaysBounceVertical = true
        collectionView?.backgroundColor = UIColor.white
        collectionView?.register(ChatCell.self, forCellWithReuseIdentifier: cellID)
        
        collectionView?.keyboardDismissMode = .interactive
        
        Inputsetup()
        
        setupKeyboardO()
    }
    
    func setupKeyboardO() {
        NotificationCenter.default.addObserver(self, selector: #selector(showKeyboard), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(showKeyboard), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    var KeyborardAnchor: NSLayoutConstraint?
    
    @objc func showKeyboard(_ notification: Notification) {
        let keyboardFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as AnyObject).cgRectValue
        let keyboardDuration = (notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as AnyObject).doubleValue
        
        KeyborardAnchor?.constant = -keyboardFrame!.height
        UIView.animate(withDuration: keyboardDuration!, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    @objc func hideKeyboard(_ notification: Notification) {
        let keyboardDuration = (notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as AnyObject).doubleValue
        
        KeyborardAnchor?.constant = 0
        UIView.animate(withDuration: keyboardDuration!, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellID, for: indexPath) as! ChatCell
        
        let message = messages[indexPath.item]
        cell.textView.text = message.text
        
        Cellsetup(cell: cell, message: message)
        cell.bubbleAnchor?.constant = TextFrame(message.text!).width + 30
        
        return cell
    }
    
    private func Cellsetup(cell: ChatCell, message: MessageStuff) {
    
        if message.SenderID == Auth.auth().currentUser?.uid {
            cell.bubbleView.backgroundColor = UIColor(red: 0/255, green: 137/255, blue: 249/255, alpha: 1)
            cell.textView.textColor = UIColor.white
            
            cell.bubbleRightAnchor?.isActive = true
            cell.bubbleLeftAnchor?.isActive = false
        }else {
            cell.bubbleView.backgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)
            cell.textView.textColor = UIColor.black
            
            cell.bubbleRightAnchor?.isActive = false
            cell.bubbleLeftAnchor?.isActive = true
            
            
            
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        collectionView?.collectionViewLayout.invalidateLayout()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        var height: CGFloat = 80
        
        if let text = messages[indexPath.item].text {
            height = TextFrame(text).height + 20
        }
        
        return CGSize(width: view.frame.width, height: height)
    }
    
    fileprivate func TextFrame(_ text: String) -> CGRect {
        let size = CGSize(width: 200, height: 1000)
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        return NSString(string: text).boundingRect(with: size, options: options, attributes: [kCTFontAttributeName as NSAttributedString.Key: UIFont.systemFont(ofSize: 16)], context: nil)
    }
    
    func Inputsetup() {
        let containerView = UIView()
        containerView.backgroundColor = UIColor.white
        containerView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(containerView)
        
        containerView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        KeyborardAnchor = containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        KeyborardAnchor?.isActive = true
        containerView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        containerView.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        let sendButton = UIButton(type: .system)
        sendButton.setTitle("Send", for: UIControl.State())
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        sendButton.addTarget(self, action: #selector(SendFunction), for: .touchUpInside)
        containerView.addSubview(sendButton)
        
        sendButton.rightAnchor.constraint(equalTo: containerView.rightAnchor).isActive = true
        sendButton.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        sendButton.widthAnchor.constraint(equalToConstant: 80).isActive = true
        sendButton.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        containerView.addSubview(inputTextField)
    
        inputTextField.leftAnchor.constraint(equalTo: containerView.leftAnchor, constant: 8).isActive = true
        inputTextField.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true
        inputTextField.rightAnchor.constraint(equalTo: sendButton.leftAnchor).isActive = true
        inputTextField.heightAnchor.constraint(equalTo: containerView.heightAnchor).isActive = true
        
        let LineSpace = UIView()
        LineSpace.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1)
        LineSpace.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(LineSpace)
        
        LineSpace.leftAnchor.constraint(equalTo: containerView.leftAnchor).isActive = true
        LineSpace.topAnchor.constraint(equalTo: containerView.topAnchor).isActive = true
        LineSpace.widthAnchor.constraint(equalTo: containerView.widthAnchor).isActive = true
        LineSpace.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    @objc func SendFunction() {
        let ref = Database.database().reference().child("messages")
        let childRef = ref.childByAutoId()
        let RecieveID = user!.id!
        let SenderID = Auth.auth().currentUser!.uid
        let TimeSent = Int(Date().timeIntervalSince1970)
        let values = ["text": inputTextField.text!, "RecieveID": RecieveID, "SenderID": SenderID, "TimeSent": TimeSent] as [String : Any]
        childRef.updateChildValues(values) { (error, ref) in
            if error != nil {
            print(error ?? "")
            return
        }
            self.inputTextField.text = nil
            
            guard let messageId = childRef.key else { return }
            let userMessage = Database.database().reference().child("user-messages").child(SenderID).child(messageId)
            
            userMessage.setValue(1)
            
            let recipientMessages = Database.database().reference().child("user-messages").child(RecieveID).child(messageId)
            recipientMessages.setValue(1)
            
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        SendFunction()
        return true
    }
}
